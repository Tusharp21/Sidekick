# Neural_Network_NEAT
This is the code for a self driving Neural Network using NEAT in Python

To execute it, run main.py in python 3.7.
You also need NEAT, pygame, numpy and scipy

To just tweak the settings without modifying the code, you can do it in config_variables.py and config_file.txt 

This code can be improved in many different ways, depending on your needs (for example the sensors at the back of the cars are useless, I just placed them there to create a general model that could fit in a more complex environment.
