package com.majorproject.therudhirapp.Email;

public class Util {

    public static final String EMAIL = "developerofandroid@gmail.com";
    public static final String PASSWORD = "TU5HA12_developer";
}
