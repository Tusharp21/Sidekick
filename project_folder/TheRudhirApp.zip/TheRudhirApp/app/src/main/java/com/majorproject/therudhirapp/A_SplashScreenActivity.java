package com.majorproject.therudhirapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class A_SplashScreenActivity extends AppCompatActivity {

    private ImageView appLogo;
    private TextView appTitle, appSlogan;

    Animation topAnim, butoomAnim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asplash_screen);

        appLogo = findViewById(R.id.appLogo);
        appTitle = findViewById(R.id.appTitle);
        appSlogan = findViewById(R.id.appSlogan);

        topAnim = AnimationUtils.loadAnimation(this,R.anim.top_anim);
        butoomAnim = AnimationUtils.loadAnimation(this,R.anim.bottom_anim);

        appLogo.setAnimation(topAnim);
        appTitle.setAnimation(butoomAnim);
        appSlogan.setAnimation(butoomAnim);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(A_SplashScreenActivity.this, B_LoginActivity.class);
                startActivity(intent);
                finish();
            }
        },4000);
    }
}