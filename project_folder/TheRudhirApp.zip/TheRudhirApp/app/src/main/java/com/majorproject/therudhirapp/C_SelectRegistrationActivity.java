package com.majorproject.therudhirapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class C_SelectRegistrationActivity extends AppCompatActivity {

    private Button donorBtn, recipientBtn;
    private TextView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cselect_registration);

        donorBtn = findViewById(R.id.donorBtn);
        recipientBtn = findViewById(R.id.recipientBtn);
        backBtn = findViewById(R.id.backBtn);

        donorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(C_SelectRegistrationActivity.this, D_DonorRegistrationActivity.class);
                startActivity(intent);
            }
        });

        recipientBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(C_SelectRegistrationActivity.this, E_RecipientRegistrationActivity.class);
                startActivity(intent);
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(C_SelectRegistrationActivity.this, B_LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}